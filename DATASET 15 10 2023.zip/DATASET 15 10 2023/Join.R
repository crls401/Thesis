install.packages("scales")
install.packages("hrbrthemes")
install.packages("gfonts")
install.packages("tidyr")
install.packages("dplyr")

library(tidyverse)
library(eurostat)
library(scales)
library(lubridate)
library(ggpubr)
library(ggthemes)
library(hrbrthemes)
library(gfonts)
library(dplyr)
library(purrr)
library(lubridate)
hrbrthemes::import_roboto_condensed()
############################ pop and death #####################################
str(pop_mort)

pop_mort <-inner_join(death1, pop, by = c("geo", "NUTS3", "NUTS2","NUTS1", "sex", "age","year")) %>%
  rename(mort = OBS_VALUE.x, popu = OBS_VALUE.y)
pop_mort <- pop_mort[, !(names(pop_mort) %in% c("OBS_FLAG.x", "OBS_FLAG.y"))]


########################### Pollution and NUTS #################################
str(NO2)
str(nuts)
str(PM2.5_NUTS)

colnames(NO2) <- c("NUTS3.Name", "year", "week", "NO2")
colnames(PM10) <- c("NUTS3.Name", "year", "week", "PM10")
colnames(PM2.5) <- c("NUTS3.Name", "year", "week", "PM2.5")
colnames(O3) <- c("NUTS3.Name", "year", "week", "O3")



NO2_NUTS <-full_join(NO2, nuts, by = c("NUTS3.Name")) 
NO2_NUTS <- NO2_NUTS[, !(names(NO2_NUTS) %in% c("X", "X.1", "X.2", "X.3"))]

freq_table_NO2_NUTS <- NO2_NUTS %>% count(NUTS3)
print(freq_table_NO2_NUTS)


PM10_NUTS <-inner_join(PM10, nuts, by = c("NUTS3.Name")) 
PM10_NUTS <- PM10_NUTS[, !(names(PM10_NUTS) %in% c("X", "X.1", "X.2", "X.3"))]

PM2.5_NUTS <-inner_join(PM2.5, nuts, by = c("NUTS3.Name")) 
PM2.5_NUTS <- PM2.5_NUTS[, !(names(PM2.5_NUTS) %in% c("X", "X.1", "X.2", "X.3"))]

O3_NUTS <-inner_join(O3, nuts, by = c("NUTS3.Name"))
O3_NUTS <- O3_NUTS[, !(names(O3_NUTS) %in% c("X", "X.1", "X.2", "X.3"))]


# Inner joins
poll <- inner_join(NO2_NUTS, PM10_NUTS, by = c("NUTS3.Name","year","week"))
poll <- inner_join(poll, PM2.5_NUTS, by = c("NUTS3.Name","year","week"))
poll <- inner_join(poll, O3_NUTS, by = c("NUTS3.Name","year","week"))
str(poll)
poll <- poll[, !(names(poll) %in% c("NUTS3.x.x", "NUTS3.y.y", "NUTS3.y"))]
names(poll)[names(poll) == "NUTS3.x"] <- "NUTS3"


################################pollution, Mortality and Population#############
str(pop_mort)
str(poll)

pol_pop_mort <- inner_join(pop_mort, poll, by = c("NUTS3", "year", "week"))
pol_pop_mort <- inner_join(pol_pop_mort, nuts_Struct, by = c("NUTS3"))
pol_pop_mort <- pol_pop_mort[, !(names(pol_pop_mort) %in% c("NUTS1.x", "NUTS2.x"))]
names(pol_pop_mort)[names(pol_pop_mort) == "NUTS1.y"] <- "NUTS1"
names(pol_pop_mort)[names(pol_pop_mort) == "NUTS2.y"] <- "NUTS2"

freq_table_pol_pop_mort <- pol_pop_mort %>% count(NUTS1)
print(freq_table_pol_pop_mort)


######################pollution, Mortality, Population and Temperature##########

final_dataset<- inner_join(pol_pop_mort, temp_Euro, by = c("NUTS2", "week"))


freq_table_NUTS2 <- final_dataset %>% count(NUTS2)
print(freq_table_NUTS2)

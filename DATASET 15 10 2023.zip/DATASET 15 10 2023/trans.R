install.packages("tidyr")
install.packages("eurostat")
install.packages("lubridate")
install.packages("scales")
install.packages("hrbrthemes")
install.packages("gfonts")
install.packages("tidyr")
install.packages("dplyr")
library(remotes)
library(eurostat)
library(tidyverse)
library(rsdmx)
library(eurostat)
library(tidyr)
library(lubridate)
library(stringr)
library(scales)
library(ggpubr)
library(ggthemes)
library(hrbrthemes)
library(gfonts)
library(dplyr)
library(purrr)
library(reshape2)
library(openxlsx)
################################NUTS############################################
path7 <- "\\estat_demo_r_mweek3_filtered_en.csv.gz"
nuts <- read.csv(path7)
str(nuts)

nuts <- nuts[, !(names(nuts) %in% c("LAST.UPDATE","DATAFLOW", "sex","TIME_PERIOD", "freq","unit", "OBS_FLAG", "OBS_VALUE"))]
nuts <- separate(nuts, geo, into = c("NUTS3", "NUTS3.Name"), sep = ":", remove = FALSE)
nuts <- nuts[, !(names(nuts) %in% c("geo","age"))]

replacement_dict <- c("Asturias" = "Oviedo", "Cantabria" = "Santander","Araba/Álava" = "Vitoria/Gasteiz", "GipuzkoaSan" = "Sebastián/Donostia","Bizkaia" = "Bilbao", "Navarra" = "Pamplona/Iruña", "La Rioja" = "Logroño", "Castellón/Castelló" = "Castellón de la Plana/Castelló de la Plana", "Valencia/València" = "Valencia", "Mallorca" = "Palma de Mallorca", "Gran Canaria" = "Las Palmas", "Lanzarote" = "Arrecife", "Tenerife" = "Santa Cruz de Tenerife")

nuts <- nuts %>% 
  mutate(NUTS3.Name = recode(NUTS3.Name, !!!replacement_dict))


#NUTS reference dataframe
path8 <- "\\Book3.csv"
nuts_Struct <- read.csv(path8)

###############################MORTALITY########################################
# Windows file path example
path <- "\\estat_demo_r_mweek3_filtered_en.csv.gz"

# read the CSV file
death <- read.csv(path)

# separate the TIME_PERIOD column into two columns
death1 <- separate(death, TIME_PERIOD, into = c("year", "week"), sep = "-") 
death1$year <- as.integer(death1$year)

# Create new columns for NUTS
death1$NUTS1 <- ifelse(nchar(death1$geo) == 2, death1$geo, NA)
death1$NUTS2 <- ifelse(nchar(death1$geo) == 4, death1$geo, NA)
death1$NUTS3 <- ifelse(nchar(death1$geo) == 5, death1$geo, NA)

death1 <- death1[, !(names(death1) %in% c("NUTS0", "STRUCTURE","STRUCTURE_ID", "freq","unit", "OBS_FLAG "))]

############################## POPOLATION ######################################
path2 <- "\\estat_demo_r_pjangrp3_filtered_en.csv.gz"

# read the CSV file
pop <- read.csv(path2)
names(pop)[names(pop) == "TIME_PERIOD"] <- "year"

# Create new columns for NUTS
pop$NUTS1 <- ifelse(nchar(pop$geo) == 2, pop$geo, NA)
pop$NUTS2 <- ifelse(nchar(pop$geo) == 4, pop$geo, NA)
pop$NUTS3 <- ifelse(nchar(pop$geo) == 5, pop$geo, NA)
pop <- pop[, !(names(pop) %in% c( "STRUCTURE","STRUCTURE_ID", "freq","unit", "OBS_FLAG "))]

###############################POLLUTION##########################################
path3 <- "\\Graph_week_data NO2.csv"
NO2 <- read.csv(path3)
path4 <- "\\Graph_week_data O3.csv"
O3 <- read.csv(path4)
path5 <- "\\Graph_week_data pm2.5.csv"
PM2.5 <- read.csv(path5)
path6 <- "\\Graph_week_data PM10.csv"
PM10 <- read.csv(path6)
str(NO2)

#Change the format for weeks
NO2$Week.of.datebegin <- week(as.Date(NO2$Week.of.datebegin, format = "%B %d, %Y")) 
NO2$Week.of.datebegin <- paste0("W",NO2$Week.of.datebegin)

O3$Week.of.datebegin <- week(as.Date(O3$Week.of.datebegin, format = "%B %d, %Y"))
O3$Week.of.datebegin <- paste0("W", O3$Week.of.datebegin)


PM2.5$Week.of.datebegin <- week(as.Date(PM2.5$Week.of.datebegin, format = "%B %d, %Y"))
PM2.5$Week.of.datebegin <- paste0("W", PM2.5$Week.of.datebegin)

PM10$Week.of.datebegin <- week(as.Date(PM10$Week.of.datebegin, format = "%B %d, %Y"))
PM10$Week.of.datebegin <- paste0("W", PM10$Week.of.datebegin)



#########################################################Temperature#######################################
path9 <- "\\H_ERA5_ECMW_T639_TA-_0002m_Euro_NUT2_S197901010000_E202309302300_INS_TIM_01d_NA-_noc_org_NA_NA---_NA---_NA---.csv"
temp <- read.csv(path9)


install.packages("reshape2")
library(reshape2)
temp_Euro <- melt(temp, id.vars = "Date", variable.name = "Geo", value.name = "Temperature")

# Step 1: Transforming Date to weeks and creating the 'week' column
temp_Euro<- temp_Euro %>%
  mutate(Date = as.Date(Date, format = "%m/%d/%Y")) %>%
  mutate(week = paste0("W", format(Date, format = "%V")))

# Step 2: Renaming Geo as NUTS2
temp_Euro <- temp_Euro %>%
  rename(NUTS2 = Geo)

# Step 3: Converting temperature from Kelvin to Celsius
temp_Euro$Temperature <- temp_Euro$Temperature - 273.15